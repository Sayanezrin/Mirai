package com.example.mirai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
