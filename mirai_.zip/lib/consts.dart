const String GEMINI_API_KEY = "AIzaSyAmzhfCjNRiQoxUh-e-uyG5B9bC1Ebf-2A";
